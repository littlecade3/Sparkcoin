import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Rocket, 
  Shield, 
  TrendingUp, 
  Wallet, 
  Copy, 
  ExternalLink,
  Twitter,
  Send,
  MessageCircle,
  ChevronRight,
  CheckCircle2,
  Circle,
  Flame,
  Lock,
  UserX
} from 'lucide-react';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

// Starfield Component
const Starfield = () => {
  const stars = Array.from({ length: 100 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: Math.random() * 2 + 1,
    delay: Math.random() * 3,
    duration: Math.random() * 2 + 2,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {stars.map((star) => (
        <div
          key={star.id}
          className="star"
          style={{
            left: star.left,
            top: star.top,
            width: `${star.size}px`,
            height: `${star.size}px`,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.duration}s`,
          }}
        />
      ))}
    </div>
  );
};

// Neon Grid Component
const NeonGrid = ({ opacity = 0.3 }: { opacity?: number }) => (
  <div 
    className="fixed inset-0 pointer-events-none z-0"
    style={{ opacity }}
  >
    <div 
      className="absolute bottom-0 left-0 right-0 h-[60vh] neon-grid"
      style={{ transform: 'perspective(500px) rotateX(70deg)', transformOrigin: 'center bottom' }}
    />
  </div>
);

// Navigation Component
const Navigation = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
    <div className="flex items-center justify-between max-w-7xl mx-auto">
      <div className="font-display text-xl text-neon-violet text-glow">
        MOONDOGE
      </div>
      <div className="hidden md:flex items-center gap-8">
        <a href="#about" className="text-text-secondary hover:text-neon-violet transition-colors text-sm font-medium">About</a>
        <a href="#tokenomics" className="text-text-secondary hover:text-neon-violet transition-colors text-sm font-medium">Tokenomics</a>
        <a href="#roadmap" className="text-text-secondary hover:text-neon-violet transition-colors text-sm font-medium">Roadmap</a>
        <a href="#buy" className="text-text-secondary hover:text-neon-violet transition-colors text-sm font-medium">Buy</a>
      </div>
      <button className="btn-primary text-sm py-2 px-4">
        Buy $MDOGE
      </button>
    </div>
  </nav>
);

// Social Links Component
const SocialLinks = () => (
  <div className="fixed bottom-6 left-6 z-50 flex gap-4">
    <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors">
      <Twitter size={20} />
    </a>
    <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors">
      <Send size={20} />
    </a>
    <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors">
      <MessageCircle size={20} />
    </a>
  </div>
);

// Hero Section
const HeroSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const doge = dogeRef.current;
    const content = contentRef.current;
    if (!section || !doge || !content) return;

    const ctx = gsap.context(() => {
      // Auto-play entrance animation
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });
      
      tl.fromTo(doge, 
        { y: '18vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, duration: 0.9, ease: 'back.out(1.6)' }
      )
      .fromTo(content,
        { x: '10vw', opacity: 0 },
        { x: 0, opacity: 1, duration: 0.8 },
        '-=0.5'
      );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            gsap.set(doge, { y: 0, opacity: 1 });
            gsap.set(content, { x: 0, opacity: 1 });
          }
        }
      });

      // Exit phase
      scrollTl.fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-22vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="section-pinned flex items-center justify-center z-10">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge Mascot */}
        <div className="flex justify-center lg:justify-start order-2 lg:order-1">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge Mascot" 
            className="w-[70vw] max-w-[400px] lg:w-[28vw] lg:max-w-none animate-float"
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="order-1 lg:order-2 text-center lg:text-left">
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-text-primary text-glow mb-4">
            TO THE MOON
          </h1>
          <p className="text-lg sm:text-xl text-text-secondary mb-2">
            The meme coin that actually launches.
          </p>
          <p className="text-sm text-neon-cyan mb-8 font-accent tracking-wider">
            Zero taxes. Liquidity locked. Community owned.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <button className="btn-primary flex items-center justify-center gap-2">
              <Rocket size={18} />
              Buy $MDOGE
            </button>
            <button className="btn-secondary flex items-center justify-center gap-2">
              <TrendingUp size={18} />
              View Chart
            </button>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-6 right-6 text-text-secondary text-xs font-accent tracking-widest">
        Scroll to launch
      </div>
    </section>
  );
};

// Why MoonDoge Section
const WhySection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // Entrance
      scrollTl.fromTo(content,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { y: '40vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      )
      // Exit
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="about" className="section-pinned flex items-center justify-center z-20">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
            style={{ transform: 'scaleX(-1)' }}
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-6">
            MEME-POWERED
          </h2>
          <ul className="space-y-4 mb-8">
            {[
              'Community-first launches with no insiders.',
              'Zero buy/sell tax—keep what you earn.',
              'Liquidity burned so the rocket stays fueled.',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-text-secondary">
                <ChevronRight className="text-neon-violet mt-1 flex-shrink-0" size={18} />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <button className="btn-primary">
            Join the Pack
          </button>
        </div>
      </div>
    </section>
  );
};

// Community Section
const CommunitySection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      scrollTl.fromTo(content,
        { x: '60vw', rotate: 2, opacity: 0 },
        { x: 0, rotate: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { x: '-20vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const stats = [
    { label: 'Holders', value: '12.5K+' },
    { label: 'Telegram', value: '8.2K+' },
    { label: 'Twitter', value: '24K+' },
  ];

  return (
    <section ref={sectionRef} className="section-pinned flex items-center justify-center z-30">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <span className="text-neon-cyan text-xs font-accent tracking-widest uppercase mb-2 block">
            Community
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-4">
            THE PACK
          </h2>
          <p className="text-text-secondary mb-6">
            A global crew of holders, meme lords, and chart watchers. If you're here early, you're already part of the story.
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-display text-xl sm:text-2xl text-neon-violet text-glow">
                  {stat.value}
                </div>
                <div className="text-xs text-text-secondary font-accent tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
          
          <img 
            src="/community-photo.jpg" 
            alt="Community" 
            className="w-full h-32 object-cover rounded-xl mb-6 opacity-80"
          />
          
          <button className="btn-primary flex items-center gap-2">
            <Send size={18} />
            Join Telegram
          </button>
        </div>
      </div>
    </section>
  );
};

// Tokenomics Section
const TokenomicsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      scrollTl.fromTo(content,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { y: '35vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const chips = [
    { icon: TrendingUp, label: 'Total Supply', value: '1T $MDOGE' },
    { icon: Lock, label: 'Tax', value: '0% Buy/Sell' },
    { icon: Flame, label: 'Liquidity', value: 'Burned' },
    { icon: UserX, label: 'Ownership', value: 'Renounced' },
  ];

  return (
    <section ref={sectionRef} id="tokenomics" className="section-pinned flex items-center justify-center z-40">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
            style={{ transform: 'scaleX(-1)' }}
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-6">
            FAIR LAUNCH
          </h2>
          
          <div className="grid grid-cols-2 gap-4 mb-8">
            {chips.map((chip, i) => (
              <div key={i} className="bg-space-dark/50 border border-neon-violet/30 rounded-xl p-4 text-center">
                <chip.icon className="text-neon-violet mx-auto mb-2" size={24} />
                <div className="text-xs text-text-secondary font-accent tracking-wider mb-1">
                  {chip.label}
                </div>
                <div className="font-display text-sm text-text-primary">
                  {chip.value}
                </div>
              </div>
            ))}
          </div>
          
          <button className="btn-secondary flex items-center gap-2">
            <ExternalLink size={18} />
            View Contract
          </button>
        </div>
      </div>
    </section>
  );
};

// Roadmap Section
const RoadmapSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      scrollTl.fromTo(content,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { y: '35vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const milestones = [
    { status: 'completed', title: 'Launch', desc: 'Fair launch, liquidity burned' },
    { status: 'progress', title: 'Community Growth', desc: 'Meme contests, raids, partnerships' },
    { status: 'upcoming', title: 'Exchange Listings', desc: 'CEX + DEX expansion' },
    { status: 'future', title: 'Moon Kit', desc: 'NFT drops, merch, on-chain games' },
  ];

  return (
    <section ref={sectionRef} id="roadmap" className="section-pinned flex items-center justify-center z-50">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-6">
            LAUNCH SEQUENCE
          </h2>
          
          <div className="space-y-4 mb-8">
            {milestones.map((milestone, i) => (
              <div key={i} className="flex items-start gap-4">
                {milestone.status === 'completed' ? (
                  <CheckCircle2 className="text-neon-violet mt-1 flex-shrink-0" size={20} />
                ) : milestone.status === 'progress' ? (
                  <div className="w-5 h-5 rounded-full border-2 border-neon-cyan mt-1 flex-shrink-0 animate-pulse" />
                ) : (
                  <Circle className="text-text-secondary mt-1 flex-shrink-0" size={20} />
                )}
                <div>
                  <div className={`font-display text-sm ${
                    milestone.status === 'completed' ? 'text-neon-violet' : 
                    milestone.status === 'progress' ? 'text-neon-cyan' : 'text-text-secondary'
                  }`}>
                    {milestone.title}
                  </div>
                  <div className="text-text-secondary text-sm">
                    {milestone.desc}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <button className="btn-secondary">
            Submit Idea
          </button>
        </div>
      </div>
    </section>
  );
};

// Safety Section
const SafetySection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      scrollTl.fromTo(content,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { y: '35vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="section-pinned flex items-center justify-center z-[60]">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
            style={{ transform: 'scaleX(-1)' }}
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="text-neon-violet" size={32} />
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow">
              SECURE & AUDITED
            </h2>
          </div>
          
          <ul className="space-y-4 mb-8">
            {[
              'Contract audited by a third-party security firm.',
              'No mint function. No blacklist. No hidden switches.',
              'Liquidity burned = no rug pull mechanics.',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-text-secondary">
                <CheckCircle2 className="text-neon-violet mt-1 flex-shrink-0" size={18} />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          
          <button className="btn-secondary flex items-center gap-2">
            <ExternalLink size={18} />
            Read Audit
          </button>
        </div>
      </div>
    </section>
  );
};

// How to Buy Section
const BuySection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dogeRef = useRef<HTMLImageElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const doge = dogeRef.current;
    if (!section || !content || !doge) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      scrollTl.fromTo(content,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(doge,
        { y: '35vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      )
      .fromTo(content,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      )
      .fromTo(doge,
        { y: 0, opacity: 1 },
        { y: '-26vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const steps = [
    { icon: Wallet, title: 'Create Wallet', desc: 'Download MetaMask or your favorite wallet.' },
    { icon: TrendingUp, title: 'Add ETH', desc: 'Bridge or deposit ETH to buy.' },
    { icon: Rocket, title: 'Swap', desc: 'Use Uniswap and paste the contract.' },
  ];

  return (
    <section ref={sectionRef} id="buy" className="section-pinned flex items-center justify-center z-[70]">
      <div className="relative w-full max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Doge */}
        <div className="flex justify-center lg:justify-start">
          <img 
            ref={dogeRef}
            src="/doge-mascot.png" 
            alt="MoonDoge" 
            className="w-[60vw] max-w-[350px] lg:w-[28vw] lg:max-w-none"
          />
        </div>
        
        {/* Content */}
        <div ref={contentRef} className="glass-card p-8 lg:p-10">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-6">
            GET ONBOARD
          </h2>
          
          <div className="space-y-4 mb-8">
            {steps.map((step, i) => (
              <div key={i} className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-neon-violet/20 border border-neon-violet flex items-center justify-center flex-shrink-0">
                  <span className="font-display text-sm text-neon-violet">{i + 1}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <step.icon className="text-neon-cyan" size={16} />
                    <span className="font-display text-sm text-text-primary">{step.title}</span>
                  </div>
                  <div className="text-text-secondary text-sm">{step.desc}</div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="btn-primary flex items-center justify-center gap-2">
              <Rocket size={18} />
              Buy $MDOGE
            </button>
            <button className="btn-secondary flex items-center justify-center gap-2">
              <Copy size={18} />
              Copy Contract
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

// Charts Section (Flowing)
const ChartsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(content,
        { y: '8vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 30%',
            scrub: 0.5,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const updates = [
    'New partnership teaser dropping soon.',
    'Meme contest winners announced.',
    'Liquidity burn tx: 0x71c…a3f4',
  ];

  return (
    <section ref={sectionRef} className="relative py-20 z-[80]">
      <div ref={contentRef} className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-4">
            MOON CHARTS
          </h2>
          <p className="text-text-secondary">
            Track the mission in real time.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Price Card */}
          <div className="glass-card p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-text-secondary text-sm font-accent tracking-wider">$MDOGE Price</span>
              <TrendingUp className="text-neon-violet" size={20} />
            </div>
            <div className="font-display text-3xl text-text-primary mb-2">
              $0.000042
            </div>
            <div className="text-neon-cyan text-sm flex items-center gap-1">
              <TrendingUp size={14} />
              +12.4%
            </div>
            {/* Sparkline SVG */}
            <svg className="w-full h-16 mt-4" viewBox="0 0 200 50">
              <path
                d="M0,40 Q20,35 40,30 T80,25 T120,20 T160,15 T200,10"
                fill="none"
                stroke="#B14BFF"
                strokeWidth="2"
                className="drop-shadow-[0_0_8px_rgba(177,75,255,0.5)]"
              />
            </svg>
          </div>
          
          {/* Updates Card */}
          <div className="glass-card p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-text-secondary text-sm font-accent tracking-wider">Latest Updates</span>
              <MessageCircle className="text-neon-violet" size={20} />
            </div>
            <ul className="space-y-3">
              {updates.map((update, i) => (
                <li key={i} className="flex items-start gap-2 text-text-secondary text-sm">
                  <div className="w-1.5 h-1.5 rounded-full bg-neon-violet mt-2 flex-shrink-0" />
                  <span>{update}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Chart Placeholder */}
        <div className="glass-card p-4 h-64 flex items-center justify-center border-dashed border-2 border-neon-violet/30">
          <div className="text-center">
            <TrendingUp className="text-neon-violet mx-auto mb-2" size={32} />
            <span className="text-text-secondary text-sm">Live Chart Integration</span>
          </div>
        </div>
      </div>
    </section>
  );
};

// Footer Section (Flowing)
const FooterSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(content,
        { y: '7vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 40%',
            scrub: 0.5,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 z-[90]">
      <div ref={contentRef} className="max-w-3xl mx-auto px-6 text-center">
        <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-text-primary text-glow mb-4">
          JOIN THE MISSION
        </h2>
        <p className="text-text-secondary mb-8">
          Hold. Meme. Repeat. The rocket is fueled by the community.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button className="btn-primary flex items-center justify-center gap-2">
            <Rocket size={18} />
            Buy $MDOGE
          </button>
          <button className="btn-pink flex items-center justify-center gap-2">
            <Send size={18} />
            Join Telegram
          </button>
        </div>
        
        {/* Footer Links */}
        <div className="grid grid-cols-3 gap-8 mb-12 text-left">
          <div>
            <h4 className="font-accent text-sm text-text-primary tracking-wider mb-4">Product</h4>
            <ul className="space-y-2">
              {['Tokenomics', 'Roadmap', 'Brand Kit'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors text-sm">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-accent text-sm text-text-primary tracking-wider mb-4">Company</h4>
            <ul className="space-y-2">
              {['Contact', 'Press', 'Careers'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors text-sm">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-accent text-sm text-text-primary tracking-wider mb-4">Legal</h4>
            <ul className="space-y-2">
              {['Terms', 'Privacy', 'Audit Report'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-text-secondary hover:text-neon-violet transition-colors text-sm">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Disclaimer */}
        <p className="text-text-secondary/60 text-xs max-w-xl mx-auto">
          This is not financial advice. Crypto is volatile—only risk what you can afford to lose.
        </p>
        
        <div className="mt-8 text-text-secondary/40 text-xs">
          © 2024 MoonDoge. All rights reserved.
        </div>
      </div>
    </section>
  );
};

// Main App
function App() {
  useEffect(() => {
    // Global snap for pinned sections
    const setupSnap = () => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
            if (!inPinned) return value;
            
            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        }
      });
    };

    // Delay to ensure all ScrollTriggers are created
    const timer = setTimeout(setupSnap, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative min-h-screen bg-space-black">
      <Starfield />
      <NeonGrid />
      <Navigation />
      <SocialLinks />
      
      <main className="relative">
        <HeroSection />
        <WhySection />
        <CommunitySection />
        <TokenomicsSection />
        <RoadmapSection />
        <SafetySection />
        <BuySection />
        <ChartsSection />
        <FooterSection />
      </main>
      
      {/* Noise overlay */}
      <div className="noise-overlay" />
    </div>
  );
}

export default App;
